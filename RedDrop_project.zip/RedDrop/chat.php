<?php include('server.php'); ?>
<?php include('functions.php'); ?>
<?php include('nav.php'); ?>
<?php
if (!isset($_GET['ID'])) {
    header('location: search.php');
} else {
    $reciever_id = getIdByPhone(getPhoneById($_GET['ID']));
    $sender_id = getIdByPhone($_SESSION['phone_number']);
    $chat_id = getChatId($sender_id, $reciever_id);
    $dtime = $_POST['dtime'];
}
if (isset($_POST['send'])) {
    $sender_id = getIdByPhone($_SESSION['phone_number']);
    $reciever_id = getIdByPhone(getPhoneById($_GET['ID']));
    $chat_id = getChatId($sender_id, $reciever_id);
    $message = $_POST['message'];
    if ($chat_id == null) {
        $query = "select max(chat_ID) from chat_box group by chat_ID";
        $result = mysqli_query($db, $query);
        $row = mysqli_fetch_assoc($result);
        $cid = (int) $row;
        $chat_id++;
    }
    $sql = "INSERT INTO chat_box (sender_ID, receiver_ID,chat_ID, message) VALUES('$sender_id','$reciever_id','$chat_id','$message');";
    mysqli_query($db, $sql);
    echo "inserted";
    header('location: chat.php?ID=' . $reciever_id);
}
?>
<html>
    <head>
        <style> 
            *{
                font-family:'Open Sans';
                box-sizing: border-box;
            }
            .chatContainer{
                width:400px;
                height:500px;
                border: 2px; 
            }
            .chatContainer>.chatHeader{
                width:100%;
                background: white;
                padding:5px;
                border-bottom: 1px solid
            }
            .input-group {
                margin-left: 20%;
            }
            .input-group label {
                display: block;
                text-align: left;
                margin: 3px;
            }
            .input-group input {
                height: 30px;
                width: 93%;
                padding: 5px 10px;
                font-size: 16px;
                border-radius: 5px;
                border: 1px solid gray;
            }
            .btn {
                padding: 10px;
                font-size: 15px;
                color: white;
                background: #333;
                border: none;
                border-radius: 5px;
            }

        </style>
        <title>Message</title>
        <link rel='stylesheet' type='text/css' href='css/style.css'/>
        <link rel ="stylesheet" type="text/css" href="style.css">
        <link href='http;//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800'
              rel='stylesheet' type='text/css'>
        <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    </head>
    <body>
        <div class='chatContainer' style="margin-top: 3%;">
            <?php if (!checkContact($reciever_id)) { ?>
                <div class='ChatHeader'>
                    <form action="add_contact.php" method="post">
                        <input type="hidden" name="contact" value="<?php echo $reciever_id; ?>">
                        <input type="hidden" name="me" value="<?php echo getIdByPhone($_SESSION['phone_number']); ?>">
                        <input type="submit" name="add" value="Add To Contact" class="btn"/>
                    </form>
                </div>
            <?php } else { ?>
                <h1>Already connected</h1>
            <?php } ?>            
            <div class='chatBottom'>
                <?php
                if ($chat_id != null) {
                    $query = "select * from chat_box where (sender_ID='" .
                            mysqli_escape_string($db, $sender_id) .
                            "' and receiver_ID='" . mysqli_escape_string($db, $reciever_id) .
                            "') or (sender_ID='" . mysqli_escape_string($db, $reciever_id) .
                            "' and receiver_ID='" . mysqli_escape_string($db, $sender_id) . "');";
                    $result = mysqli_query($db, $query);
                    while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                        $sql2 = "select * from registration where phone_number='" . getPhoneById($row['sender_ID']) . "';";
                        $result2 = mysqli_query($db, $sql2);
                        $row2 = mysqli_fetch_array($result2, MYSQLI_ASSOC);
                        $sender_name = $row2['fname'] . " " . $row2['lname'];
                        echo $sender_name . " : " . $row['message'] . "<br/>";
                        echo $dtime . $row['dtime'] . "<br/>";
                    }
                }
                ?>
                <form action="chat.php?ID=<?php echo $reciever_id; ?>" method="POST">
                    <div class = "input-group">
                        <input type='text' name='message' value='' placeholder='type your message here'/>
                    </div>
                    <input type="submit" name="send" class="btn" value ='Send'/>
                </form>
            </div>
        </div>
    </body>
</html>
