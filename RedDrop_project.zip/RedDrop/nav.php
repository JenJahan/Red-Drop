<!DOCTYPE html>
<html>
    <head>
        <style>
            body {margin:0;}
            ul {
                list-style-type: none;
                margin: 0;
                padding: 0;
                overflow: hidden;
                background-color: #FF5C5C;
                position: fixed;
                top: 0;
                width: 100%;
            }
            li {
                float: left;
            }
            li a {
                display: block;
                color: white;
                text-align: center;
                padding: 14px 16px;
                text-decoration: none;
            }
            li a:hover:not(.active) {
                background-color: #d10000;
            }
            .active {
                background-color: #4CAF50;
            }
            .logo {
                height: 50px;
                float: right;
            }
        </style>
    </head>
    <body>
        <ul>
            <li><a href="profile.php">Profile</a>
            <li><a href="search.php">Search</a></li>
            <li><a href="contacts.php">Contacts</a></li>
            <li><a href="my_messages.php">Messages</a></li>
            <li><a href="transactions.php">Transactions</a></li>
            <li><a href="settings.php">Settings</a></li>
            <li><a href="login.php">Logout</a></li>
            <img class="logo" src="image\rd.png">
        </ul>
    </body>
</html>
