<?php include('server.php'); ?>
<?php include('nav.php'); ?>
<?php include('functions.php'); ?>
<?php
$strSQL = $db->query("SELECT * FROM registration where phone_number =" . $_SESSION['phone_number']);
if ($row = $strSQL->fetch_assoc()) {
    $p = $row['phone_number'];
    $n1 = $row['fname'];
    $n2 = $row['mname'];
    $n3 = $row['lname'];
    $d = $row['division'];
    $c = $row['city'];
    $a = $row['area'];
}
?>
<!DOCTYPE html>
<html>
    <head>
        <style> 
            input[type=text] {
                width: 130px;
                box-sizing: border-box;
                border: 2px solid #ccc;
                border-radius: 4px;
                font-size: 16px;
                background-color: white;
                background-image: url('image/s.png');
                background-position: 10px 10px; 
                background-repeat: no-repeat;
                padding: 12px 20px 12px 40px;
                -webkit-transition: width 0.4s ease-in-out;
                transition: width 0.4s ease-in-out;
            }

            input[type=text]:focus {
                width: 100%;
            }
            table,th{
                border-top: 2px solid #333;
                border-bottom: 1px solid #333;
                padding: 5px;
                margin-left: 2%;
            }
        </style>
        <meta charset="UTF-8">
        <link rel ="stylesheet" type="text/css" href="style.css">
        <title>Red Drop</title>
    </head>
    <body>
        <div class = "header">
            <h2>Search</h2>
        </div>
        <form  method="post" action="search.php">
            <input type="radio" name="donate" value="1"> DONOR
            <span style="margin-left:8em"></span>
            <input type="radio" name="donate" value="2"> RECEIVER</br></br>
            <div class = "input-group">
                <button type = "submit" name="notify" class="btn"
                        style="margin-left:10em">Request</button>
                <p style="color: red;
                   margin-left:2em">*This notifies other account holders</p>  
            </div>
        </form>
        <?php
        if (isset($_REQUEST['notify'])) {
            $role = $_REQUEST['donate'];
            $strSQL = $db->query("SELECT * FROM success WHERE phone_number='" . $_SESSION['phone_number'] . "'");
            if ($row = $strSQL->fetch_assoc()) {
                $_SESSION['id'] = $row['ID'];
            }
            switch ($role) {
                case 1:
                    $msg = "wants to donate blood.";
                    $d = $db->query("INSERT INTO profile_notification (sender_ID,notification) VALUES('" . $_SESSION['id'] . "','$msg')");
                    break;
                case 2:
                    $msg = "needs blood.";
                    $d = $db->query("INSERT INTO profile_notification (sender_ID,notification) VALUES('" . $_SESSION['id'] . "','$msg')");
                    break;
            }
        }
        ?>
        <div class="container">
            <div class="row" >
                <form class="form-horizontal">
                    <fieldset>
                        <legend><strong>FILTER</strong></legend>
                        </br>
                        <input type="text" name="searchbar" placeholder="Search..">
                        </br></br>
                        <div
                            <label>Blood Group</label>
                            <select name="blood_group" required="">
                                <option value=""></option>
                                <option value="A+ve">A+ve</option>
                                <option value="A-ve">A-ve</option>
                                <option value="B+ve">B+ve</option>
                                <option value="B-ve">B-ve</option>
                                <option value="O+ve">O+ve</option>
                                <option value="O-ve">O-ve</option>
                                <option value="AB+ve">AB+ve</option>
                                <option value="AB-ve">AB-ve</option>
                            </select>
                        </div>
                        </br>
                        <p style="color: red;">*Select filter location type</p>
                        <input type="radio" name="radios" value="1"> DIVISION
                        <span style="margin-left:3em"></span>
                        <input type="radio" name="radios" value="2"> CITY
                        <span style="margin-left:3em"></span>
                        <input type="radio" name="radios" value="3"> AREA
                        </br></br><div class = "input-group">
                            <button type = "submit" name="search" class="btn">Search</button>
                        </div>
                    </fieldset>
                </form>
                </br></br>
                <?php
                if (isset($_REQUEST['search'])) {
                    echo "<fieldset>
                        <!-- Form Name -->
                        <legend><strong>RESULT...</strong></legend>
                        </br>
                 </fieldset>";
                    $blood_group = $_REQUEST['blood_group'];
                    if (isset($_REQUEST['blood_group'])) {
                        if (isset($_REQUEST['radios'])) {
                            $location = $_REQUEST['radios'];
                            $s = $db->query("SELECT * FROM registration WHERE blood_group = '$blood_group'");
                            echo "<table style='width: 96%'>
                                <tr>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Blood Group</th>
                                <th>Gender</th>
                                </tr>";
                            while ($row = $s->fetch_assoc()) {
                                if ($row['phone_number'] != $_SESSION['phone_number']) {
                                    switch ($location) {
                                        case 1:
                                            if ($row['division'] == $d) {
                                                echo "<tr><td><a href=user_profile.php?ID="
                                                . getIdByPhone($row['phone_number'])
                                                . ">" . $row['fname'] . ' ' . $row['mname']
                                                . ' ' . $row['lname'] . "</a></td>
                                <td>" . $row['country'] . ' , ' . $row['division'] . "</td>
                                <td>" . $row['blood_group'] . "</td>
                                <td>" . $row['gender'] . "</td>
                                        </tr>";
                                            } else {
                                                echo "</br><strong style= 'color:red'>No Result found!</strong>";
                                                echo "<td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                        </tr>";
                                            }
                                            break;
                                        case 2:
                                            if (($row['division'] == $d) && ($row['city'] == $c)) {
                                                echo "<tr><td><a href=user_profile.php?ID="
                                                . getIdByPhone($row['phone_number'])
                                                . ">" . $row['fname'] . ' ' . $row['mname']
                                                . ' ' . $row['lname'] . "</a></td>
                                <td>" . $row['country'] . ' , ' . $row['division'] . ' , ' . $row['city'] . "</td>
                                <td>" . $row['blood_group'] . "</td>
                                <td>" . $row['gender'] . "</td>
                                        </tr>";
                                            } else {
                                                echo "</br><strong style= 'color:red'>No Result found!</strong></br>";
                                                echo "<td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                        </tr>";
                                            }break;
                                        case 3:
                                            if (($row['division'] == $d) && ($row['city'] == $c) && ($row['area'] == $a)) {
                                                echo "<tr><td><a href=user_profile.php?ID="
                                                . getIdByPhone($row['phone_number'])
                                                . ">" . $row['fname'] . ' ' . $row['mname']
                                                . ' ' . $row['lname'] . "</a></td>
                                <td>" . $row['country'] . ' , ' . $row['division'] . ' , ' . $row['city'] . ' , ' . $row['area'] . "</td>
                                <td>" . $row['blood_group'] . "</td>
                                <td>" . $row['gender'] . "</td>
                                            </tr>";
                                            } else {
                                                echo "</br><strong style= 'color:red'>No Result found!</strong></br>";
                                                echo "<tr style= 'color:blue'><td>NIL</td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                        </tr>";
                                            }break;
                                    }
                                }
                            }echo "</table>";
                            $db->close();
                        } else {
                            $searchfield = $_REQUEST['searchbar'];
                            $ss = $db->query("SELECT * FROM registration WHERE blood_group = '$blood_group'
                                    AND ((fname like '%" . $searchfield . "%') OR 
                                    (mname like '%" . $searchfield . "%') OR 
                                    (lname like '%" . $searchfield . "%') OR 
                                    (division like '%" . $searchfield . "%')OR 
                                    (city like '%" . $searchfield . "%')OR 
                                    (area like '%" . $searchfield . "%'))");
                            echo "<table style='width: 96%'>
                                <tr>
                                <th>Name</th>
                                <th>Location</th>
                                <th>Blood Group</th>
                                <th>Gender</th>
                                </tr>";
                            while ($row1 = $ss->fetch_assoc()) {
                                if ($row1['phone_number'] != $_SESSION['phone_number']) {
                                    echo "<tr><td><a href=user_profile.php?ID="
                                    . getIdByPhone($row1['phone_number'])
                                    . ">" . $row1['fname'] . ' ' . $row1['mname']
                                    . ' ' . $row1['lname'] . "</a></td>
                                <td>" . $row1['country'] . ' , ' . $row1['division'] . ' , ' . $row1['city'] . ' , ' . $row1['area'] . "</td>
                                <td>" . $row1['blood_group'] . "</td>
                                <td>" . $row1['gender'] . "</td>
                                            </tr>";
                                } else {
                                    echo "</br><strong style= 'color:red'>No Result found!</strong></br>";
                                    echo "<tr style= 'color:blue'><td>NIL</td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                <td style= 'color:blue'><i>NIL</i></td>
                                        </tr>";
                                }
                            }
                            echo "</table>";
                            $db->close();
                        }
                    }
                }
                ?>
            </div>
        </div>
        </br></br>
    </body>
</html>