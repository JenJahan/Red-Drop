<?php include('nav.php'); ?>
<?php
session_start();
if (!isset($_SESSION['phone_number'])) {
    $_SESSION['msg'] = "You must log in first";
    header('location: login.php');
}
if (isset($_GET['logout'])) {
    session_destroy();
    unset($_SESSION['phone_number']);
    unset($_SESSION['id']);
    header("location: login.php");
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Home</title>
        <link rel="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class="header">
            <h2>Home Page</h2>
        </div>
        <div class="content">
            <?php if (isset($_SESSION['success'])) : ?>
                <div class="error success" >
                    <h3>
                        <?php
                        echo $_SESSION['success'];
                        unset($_SESSION['success']);
                        ?>
                    </h3>
                </div>
            <?php endif ?>
            <?php if (isset($_SESSION['phone_number'])) : ?>
                <p>Welcome <strong>
                        <?php
                        echo $_SESSION['phone_number'] . "<br />";
                        echo "ID: " . $_SESSION['id'];
                        ?>
                    <?php endif ?>
                </p>
        </div>
    </body>
</html>