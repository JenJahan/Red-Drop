<?php include('server.php'); ?>
<?php include('nav.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            *{
                margin: 0px;
                padding: 0px;
            }
            body{padding-top:10px;}
            body {
                font-size: 120%;
                background: #F8F8FF;
            }
            .header {
                width: 30%;
                margin: 50px auto 0px;
                color: white;
                background: #FF5C5C;
                text-align: center;
                border: 1px solid #333;
                border-bottom: 1px solid #333;
                border-radius: 10px 10px 0px 0px;
                padding: 20px;
            }

            .btn {
                padding: 10px;
                font-size: 15px;
                color: white;
                background:#d10000;
                border: none;
                border-radius: 5px;
            }
            h4{	margin-top:50px; }
            h4 span{ font-size:13px; color:grey; }

            .alert {
                float: right;
                width: 90%;
                padding: 20px;
                background-color: #f44336;
                color: white;
                opacity: 1;
                transition: opacity 0.6s;
                margin-bottom: 15px;
            }

            .alert.success {background-color:  #ff7373 ;}

            .closebtn {
                margin-left: 15px;
                color: white;
                font-weight: bold;
                float: right;
                font-size: 22px;
                line-height: 20px;
                cursor: pointer;
                transition: 0.3s;
            }

            .closebtn:hover {
                color: black;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link href='https://fonts.googleapis.com/css?family=Athiti' rel='stylesheet'>
    </head>
    <body>
        <div class = "header">
            <h2>Profile</h2>
        </div>
        <form method="post" action = "profile.php"> 
            <div class="container">
                <div class="row">
                    <div class="col-md-5  toppad  pull-right col-md-offset-3 " style='float: right;'>
                        <h3 align="topright"></h3>  
                        <A href="edit.php" >Edit Profile</A>
                        <br>
                        <p id="demo"></p>
                        <script>
                            document.getElementById("demo").innerHTML = Date();
                        </script>
                        </br>
                        <A href="folder.php" >File Folder</A>
                    </div>
                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad" >
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <?php
                            $strSQL = $db->query("SELECT fname,mname,lname FROM registration where phone_number =" . $_SESSION['phone_number']);
                            if ($row = $strSQL->fetch_assoc()) {
                                echo $row['fname'] . "&nbsp";
                                if ($row['mname'] != NULL) {
                                    echo $row['mname'] . "&nbsp";
                                }
                                echo $row['lname'] . "<br />";
                            }
                            ?>
                        </h3>
                    </div>
                </div>
            </div>
            <div class="panel-body" >
                <div class="row">
                    <br />
                    <?php
                    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
                    $result = mysqli_query($db, $sql);
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    $count = mysqli_num_rows($result);
                    if ($count == 1) {
                        $_SESSION['phone_number'] = $phone_number;
                    }
                    $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
                    if ($row = $strSQL->fetch_assoc()) {
                        // Write the value of the column FirstName (which is now in the array $row)
                        $_SESSION['id'] = $row['ID'];
                    }
                    $q = $db->query("SELECT * FROM profile WHERE ID='" . $_SESSION['id'] . "'");
                    while ($row = $q->fetch_assoc()) {
                        if ($row['picture'] == "") {
                            echo "<img width = '150' height = '150'
                               src = 'image/default_avatar.png' alt = 'Default Profile Picture'>" . "</br>";
                        } else {
                            echo "<img width = '150' height = '150'
                               src = 'image/" . $row['picture'] . "' alt = 'Profile Picture'>" . "</br>";
                        }
                    }
                    ?>
                    <br />

                    <div class="container">
                        <div class="row">
                            <div class="col-md-5  toppad  pull-right col-md-offset-3 " style='float: right;
                                 width:30%'>
                                <h3 align="topright">Notifications</h3>  
                                <div class="alert success">
                                    <span class="closebtn">&times;</span>  
                                    <?php
                                    $n = $db->query("SELECT * FROM profile_notification WHERE sender_ID !='" . $_SESSION['id'] . "'");
                                    while ($row = $n->fetch_assoc()) {
                                        $s = $row['sender_ID'];
                                        $not = $row['notification'];
                                        $p = $db->query("SELECT * FROM success WHERE ID ='" . $row['sender_ID'] . "'");
                                        if ($row = $p->fetch_assoc()) {
                                            $phone = $row['phone_number'];
                                            $name = $db->query("SELECT * FROM registration WHERE phone_number = '$phone'");
                                            if ($row = $name->fetch_assoc()) {
                                                $n1 = $row['fname'];
                                                $n2 = $row['mname'];
                                                $n3 = $row['lname'];
                                                echo "<a href=user_profile.php?ID=" . $s . ">" . $n1 . ' ' . $n2 . ' ' . $n3 . ' ' . $not . "</a></br>";
                                            }
                                        }
                                    }
                                    ?>
                                </div>
                                <script>
                                    var close = document.getElementsByClassName("closebtn");
                                    var i;

                                    for (i = 0; i < close.length; i++) {
                                        close[i].onclick = function () {
                                            var div = this.parentElement;
                                            div.style.opacity = "0";
                                            setTimeout(function () {
                                                div.style.display = "none";
                                            }, 600);
                                        }
                                    }
                                </script>
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="well well-sm">
                                    <div class="media">
                                        <div class="media-body">
                                            <p>
                                                <a href="my_messages.php" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-comment"></span> Message</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    </br>
                    <?php
                    echo "<table style = 'width:50%' align = 'center'>
                        <tr>
                        <th>User Information</th>
                        </tr>";
                    $strSQL = $db->query("SELECT * FROM registration where phone_number =" . $_SESSION['phone_number']);
                    $d = $db->query("SELECT COUNT(r_ID) FROM donation WHERE ((r_ID='" . $_SESSION['id'] . "') AND (status = 'Donated'))");
                    $r = $db->query("SELECT COUNT(d_ID) FROM donation WHERE (d_ID='" . $_SESSION['id'] . "' AND (status = 'Received'))");
                    $c = $db->query("SELECT * WHERE me='" . $_SESSION['id'] . "'");

                    if ($row = $strSQL->fetch_assoc()) {
                        echo "<tr><th></br>Country:&nbsp&nbsp<td></br>" . $row['country'] . "</td></th></tr>";
                        echo "<tr><th>Division:&nbsp&nbsp<td>" . $row['division'] . "</td></th></tr>";
                        echo "<tr><th>City:&nbsp&nbsp<td>" . $row['city'] . "</td></th></tr>";
                        echo "<tr><th>Area:&nbsp&nbsp<td>" . $row['area'] . "</td></th></tr>";
                        echo "<tr><th>Blood group:&nbsp&nbsp<td>" . $row['blood_group'] . "</td></th></tr>";
                        echo "<tr><th>Date of birth:&nbsp&nbsp<td>" . $row['date_of_birth'] . "</td></th></tr>";
                        echo "<tr><th>Gender:&nbsp&nbsp<td>" . $row['gender'] . "</td></th></tr>";

                        $dateOfBirth = $row['date_of_birth'];
                        $today = date("Y-m-d");
                        $diff = date_diff(date_create($dateOfBirth), date_create($today));
                        echo "<tr><th>Age:&nbsp&nbsp<td>" . $diff->format('%y') . "</td></th></tr>";
                        echo "<tr><th>Weight:&nbsp&nbsp<td>" . $row['weight'] . "</td></th></tr>";
                        echo "<tr><th>Status:&nbsp&nbsp<td>" . $row['status'] . "</td></th></tr>";
                        echo "<tr><th>Phone number:&nbsp&nbsp<td> +880" . $row['phone_number'] . "</td></th></tr>";
                        if ($row = $d->fetch_assoc()) {
                            echo "<tr><th>Donation Count:&nbsp&nbsp<td>" . $row['COUNT(r_ID)'] . "</td></th></tr>";
                        }
                        if ($row = $r->fetch_assoc()) {
                            echo "<tr><th>Receival Count:&nbsp&nbsp<td>" . $row['COUNT(d_ID)'] . "</td></th></tr>";
                        }
                    }
                    echo "</table>";
                    $s = $db->query("SELECT * FROM profile_settings WHERE profile_ID='" . $_SESSION['id'] . "'");
                    if ($row = $s->fetch_assoc()) {
                        if (($row['add_phone_number'] != 0) && ($row['city'] != "") && ($row['area'] != "")) {
                            echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                            echo "<strong>Contact number:</strong> +880" . $row['add_phone_number'] . "</br>";
                            echo "<strong>Location:</strong> " . $row['city'] . " , " . $row['area'];
                        } else if ($row['add_phone_number'] != 0) {
                            echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                            echo "<strong>Contact number:</strong> +880" . $row['add_phone_number'] . "</br>";
                        } else if (($row['city'] != "") && ($row['area'] != "")) {
                            echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                            echo "<strong>Location:</strong> " . $row['city'] . " , " . $row['area'];
                        }
                    }
                    $db->close();
                    ?>
                    <br /><br />
                </div>
            </div>
        </form> 
    </body>
</html>
