<?php include('nav.php'); ?>
<?php include('server.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            body{padding-top:10px;}
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class = "header">
            <h2>Folder</h2>
        </div>
        <form method="post" action="folder.php" enctype="multipart/form-data">
            <div>
                <input type="file" name="file">
                <input type="submit" name="upload" value = "Upload">
            </div>
            <?php
            $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
            if ($row = $strSQL->fetch_assoc()) {
                $_SESSION['id'] = $row['ID'];
            }
            $q = $db->query("SELECT * FROM profile_folder WHERE profile_ID='" . $_SESSION['id'] . "'");
            $ff = $db->query("SELECT * FROM profile WHERE ID='" . $_SESSION['id'] . "'");
            while ($row = $q->fetch_assoc()) {
                if ($row['folder'] != "") {
                    while ($row = $ff->fetch_assoc()) {
                        echo "<a href = 'healthdocs/" . $row['blood_report'] . "'>" . $row['blood_report'] . "</a";
                    }
                    echo "<a href = 'healthdocs/" . $row['folder'] . "'>" . $row['folder'] . "</a";
                } else {
                    while ($row = $ff->fetch_assoc()) {
                        if ($row['blood_report'] != "") {
                            echo "<a href = 'healthdocs/" . $row['blood_report'] . "'>" . $row['blood_report'] . "</a";
                        }
                    }
                }
            }
            ?>
        </form>
    </body>
</html>