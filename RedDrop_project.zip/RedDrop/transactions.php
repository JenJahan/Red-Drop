<?php include('server.php'); ?>
<?php include('nav.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            table,th{
                border-top: 2px solid #333;
                border-bottom: 1px solid #333;
                padding: 5px;
                margin-left: 2%;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
        </header>
        <div class = "header">
            <h2>Transaction Counts</h2>
        </div>
        <form  method="post" action="transactions.php">
            <p style="color: red;">*Select your activity</p>
            <input type="radio" name="donation" value="1"> DONATED
            <span style="margin-left:6em"></span>
            <input type="radio" name="donation" value="2"> RECEIVED
            </br>
            <div class = "input-group">
                <label>Phone Number</label>
                <input type = "text" name="phone_number" placeholder="Insert donor's/receiver's contact number">
            </div>
            <div class = "input-group">
                <label>Date of Activity</label>
                <input type = "date" name="date_of_activity">
            </div>
            <div class = "input-group">
                <button type = "submit" name="record" class="btn" >Record</button>
            </div>
        </form>
        </br></br>
        <?php
        $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
        if ($row = $strSQL->fetch_assoc()) {
            $_SESSION['id'] = $row['ID'];
        }
        $s = $db->query("SELECT * FROM donation");
        echo "<table style='width: 96%'>
                        <tr>
                        <th>Status</th>
                        <th>Name</th>
                        <th>Phone Number</th>
                        <th>Date</th>
                        </tr>";
        while ($row = $s->fetch_assoc()) {
            if ($row['r_ID'] == $_SESSION['id']) {
                $stat = $row['status'];
                $d = $row['date_of_activity'];
                $i = $db->query("SELECT * FROM success WHERE ID = '" . $row['d_ID'] . "'");
                if ($row = $i->fetch_assoc()) {
                    $p = $row['phone_number'];
                    $a = $db->query("SELECT fname,mname,lname FROM registration WHERE phone_number = '$p'");
                    if ($row = $a->fetch_assoc()) {
                        $f = $row['fname'];
                        $m = $row['mname'];
                        $l = $row['lname'];
                        echo "<tr><td>" . $stat . "</td>
                        <td>" . $f . ' ' . $m . ' ' . $l . "</td>
                        <td> +880" . $p . "</td>
                        <td>" . $d . "</td>
                        </tr>";
                    }
                }
            }
        }
        echo "</table></br></br>";
        $db->close();
        ?>
    </body>
</html>
