<?php include('server.php');?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            header {
                margin-top: 20px;
                padding-bottom: 10px;
            }
            .logo-row{
                text-align: center;
            }
            .logo {
                width: 300px;
                height: 100px;
                text-align: center;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
            <div class="row">
                <div class="logo-row">
                    <img src="image\redDrop.png" alt="logo" class="logo">
                </div>
            </div>
        </header>
        <div class = "header">
            <h2>Registration</h2>
        </div>
        <form method="post" action="registration.php">
            <?php include('errors.php');?>
            
            <div class = "input-group">
                <label>Phone Number</label>
                <input type = "text" name="phone_number">
            </div>
            
            <div class = "input-group">
                <label>Name:<br>First Name</label>
                <input type = "text" name="fname" >
                <label>Middle Name</label>
                <input type = "text" name="mname">
                <label>Last Name</label>
                <input type = "text" name="lname" >
            </div>
            
            <div class = "input-group">
                <label>Location:<br>Country<select name="country">
                    <option value=""></option>
                    <option value="Bangladesh">Bangladesh</option>
                    </select></label>
                <label>Division<select name ="division">
                    <option value=""></option>
                    <option value="Barishal">Barishal</option>
                    <option value="Chittagong">Chittagong</option>
                    <option value="Dhaka">Dhaka</option>
                    <option value="Khulna">Khulna</option>
                    <option value="Mymensingh">Mymensingh</option>
                    <option value="Rajshahi">Rajshahi</option>
                    <option value="Rongpur">Rongpur</option>
                    <option value="Syhlet">Syhlet</option>
                    </select>
                <label>City<input type = "text" name="city"></label>
                <label>Area<input type = "text" name="area"></label>
            </div>
            
            <div class = "input-group">
                <label>Date of Birth</label>
                <input type = "date" name="date_of_birth">
            </div>
            <div>
                <label>Blood Group</label>
                <select name="blood_group">
                    <option value=""></option>
                    <option value="A+ve">A+ve</option>
                    <option value="A-ve">A-ve</option>
                    <option value="B+ve">B+ve</option>
                    <option value="B-ve">B-ve</option>
                    <option value="O+ve">O+ve</option>
                    <option value="O-ve">O-ve</option>
                    <option value="AB+ve">AB+ve</option>
                    <option value="AB-ve">AB-ve</option>
                    </select>
            </div>
            <div>
                <label>Gender</label>
                <select name="gender">
                    <option value=""></option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class = "input-group">
                <label>Weight</label>
                <select name = "weight">
                <?php
                    for ($i=45; $i<=200; $i++){
                ?>
                <option value="<?php echo $i;?>"><?php echo $i;?></option>
                <?php
                }
                ?>
                </select>
            </div>
            <div> 
                <label>Status</label>
                <select name="status">
                    <option value=""></option>
                    <option value="Unmarried">Unmarried</option>
                    <option value="Married">Married</option>
                    <option value="Separated">Separated</option>
                    <option value="Widow">Widow</option>
                    </select>
                
            </div>

            <div class = "input-group">
                <label>Password</label>
                <input type = "password" name="password">
            </div>
            
            <div class = "input-group">
                <button type = "submit" name="register" class="btn">Register</button>
            </div>
            <p>
                Already a member? <a href="login.php">Sign in</a>
            </p>
        </form>
    </body>
</html>

