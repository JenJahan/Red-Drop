<?php include('server.php'); ?>
<?php include('nav.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            * {
                margin: 0px;
                padding: 0px;
            }
            body {
                font-size: 120%;
                background: #F8F8FF;
            }
            body{padding-top:10px;}
            .header {
                width: 30%;
                margin: 50px auto 0px;
                color: white;
                background: #FF5C5C;
                text-align: center;
                border: 1px solid #333;
                border-bottom: 1px solid #333;
                border-radius: 10px 10px 0px 0px;
                padding: 20px;
            }
            form, .content {
                width: 30%;
                margin: 0px auto;
                padding: 20px;
                border: 1px solid #B0C4DE;
                background: white;
                border-radius: 0px 0px 10px 10px;
            }
            .input-group {
                margin: 10px 0px 10px 0px;
            }

            .input-group label {
                display: block;
                text-align: left;
                margin: 3px;
            }
            .input-group input {
                height: 30px;
                width: 93%;
                padding: 5px 10px;
                font-size: 16px;
                border-radius: 5px;
                border: 1px solid gray;
            }
            .btn {
                padding: 10px;
                font-size: 15px;
                color: white;
                background: #d10000;
                border: none;
                border-radius: 5px;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>

        
    </head>
    <body>
        <div class = "header">
            <h2>Settings</h2>
        </div>
        <form method="post" action="settings.php">

            <div class = "input-group">
                <label>Add Phone Number</label>
                <input type = "text" name="add_phone_number">
            </div>
            
            <div class = "input-group">
                <label>Add Location:<br></label>

                <label>City<input type = "text" name="city"></label>
                <label>Area<input type = "text" name="area"></label>
            </div>
            <div class = "input-group">
                </br></br>
                <button type = "submit" name="add" class="btn">Add</button>
            </div>
        </form>
    </body>
</html>