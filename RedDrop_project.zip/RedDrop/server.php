<?php
session_start();
$phone_number = "";
$fname = "";
$lname = "";
$country = "";
$division = "";
$city = "";
$date_of_birth = "";
$blood_group = "";
$gender = "";
$password = "";
$id = "";
$picture = "";
$errors = array();
$_SESSION['success'] = "";
$_SESSION['id'] = "";
$msg = "";
$db = mysqli_connect('127.0.0.1', 'root', '', 'red_drop');

//rgistraion------------------>
if (isset($_POST['register'])) {
    $phone_number = mysqli_real_escape_string($db, $_POST['phone_number']);
    $date_of_birth = mysqli_real_escape_string($db, $_POST['date_of_birth']);
    $blood_group = mysqli_real_escape_string($db, $_POST['blood_group']);
    $gender = mysqli_real_escape_string($db, $_POST['gender']);
    $weight = mysqli_real_escape_string($db, $_POST['weight']);
    $status = mysqli_real_escape_string($db, $_POST['status']);
    $fname = mysqli_real_escape_string($db, $_POST['fname']);
    $mname = mysqli_real_escape_string($db, $_POST['mname']);
    $lname = mysqli_real_escape_string($db, $_POST['lname']);
    $country = mysqli_real_escape_string($db, $_POST['country']);
    $division = mysqli_real_escape_string($db, $_POST['division']);
    $city = mysqli_real_escape_string($db, $_POST['city']);
    $area = mysqli_real_escape_string($db, $_POST['area']);
    $password = mysqli_real_escape_string($db, $_POST['password']);

    if (empty($phone_number)) {
        array_push($errors, "Phone number is required");
    }
    if (empty($fname)) {
        array_push($errors, "First name is required");
    }
    if (empty($lname)) {
        array_push($errors, "Last name is required");
    }
    if ($country == "") {
        array_push($errors, "Country must be selected");
    }
    if ($division == "") {
        array_push($errors, "Division must be selected");
    }
    if (empty($city)) {
        array_push($errors, "City is required");
    }
    if (empty($date_of_birth)) {
        array_push($errors, "Date of birth is required");
    }
    if ($blood_group == "") {
        array_push($errors, "Blood group must be selected");
    }
    if ($gender == "") {
        array_push($errors, "Gender must be selcted");
    }
    if (empty($password)) {
        array_push($errors, "Password is required");
    }
    if (count($errors) == 0) {
        $q1 = "INSERT INTO registration (fname, mname, lname, phone_number, country,
                    division, city, area, date_of_birth, blood_group, gender, weight, status, password) 
				  VALUES('$fname','$mname','$lname','$phone_number','$country',
                        '$division','$city','$area', '$date_of_birth', '$blood_group', '$gender',
                        '$weight', '$status', '$password')";
        mysqli_query($db, $q1);
        $id = uniqid();
        $a = "INSERT INTO profile (ID) VALUES ('$id')";
        mysqli_query($db, $a);
        $b = "INSERT INTO profile_folder (profile_ID) VALUES ('$id')";
        mysqli_query($db, $b);
        $c = "INSERT INTO profile_notification (ID) VALUES ('$id')";
        mysqli_query($db, $c);
        $d = "INSERT INTO profile_settings (profile_ID) VALUES ('$id')";
        mysqli_query($db, $d);
        $e = "INSERT INTO settings_add_location (ID) VALUES ('$id')";
        mysqli_query($db, $e);
        $f = "INSERT INTO success (ID, phone_number) VALUES ('$id','$phone_number')";
        mysqli_query($db, $f);
        $_SESSION['phone_number'] = $phone_number;
        $_SESSION['id'] = $id;
        $_SESSION['success'] = "You are now logged in";
        header('location: index.php');
    }
}

//login--------------------->
if (isset($_POST['login'])) {
    $phone_number = mysqli_real_escape_string($db, $_POST['phone_number']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number' AND password='$password'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
        $_SESSION['success'] = "You are now logged in";
        $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
        if ($row = $strSQL->fetch_assoc()) {
            $_SESSION['id'] = $row['ID'];
        }
        header("location: index.php");
    } else {
        array_push($errors, "Wrong phone number/password combination");
    }
}

//edit-------------------------->
if (isset($_POST['submit'])) {
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
    }
    $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
    if ($row = $strSQL->fetch_assoc()) {
        $_SESSION['id'] = $row['ID'];
    }
    $target = "image/" . basename($_FILES['image']['name']);
    $picture = $_FILES['image']['name'];
    if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
        $msg = "Image upload successful";
    } else {
        $msg = "Thare was problem uploading image";
    }
    $c = $db->query("UPDATE profile SET picture='$picture' WHERE ID = '" . $_SESSION['id'] . "'");
}
if (isset($_POST['save_changes'])) {
    $weight = mysqli_real_escape_string($db, $_POST['weight']);
    $status = mysqli_real_escape_string($db, $_POST['status']);
    $fname = mysqli_real_escape_string($db, $_POST['fname']);
    $mname = mysqli_real_escape_string($db, $_POST['mname']);
    $lname = mysqli_real_escape_string($db, $_POST['lname']);
    $division = mysqli_real_escape_string($db, $_POST['division']);
    $city = mysqli_real_escape_string($db, $_POST['city']);
    $area = mysqli_real_escape_string($db, $_POST['area']);
    $password = mysqli_real_escape_string($db, $_POST['password']);
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
    }
    $aa = "UPDATE registration SET city = '$city',area = '$area' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $aa);
    $ab = "UPDATE registration SET division ='$division',city = '$city',area = '$area' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $ab);
    $ac = "UPDATE registration SET fname='$fname',mname = '$mname',lname = '$lname' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $ac);
    $ad = "UPDATE registration SET fname = '$fname',lname = '$lname' where phone_number" . $_SESSION['phone_number'];
    mysqli_query($db, $ad);
    $ae = "UPDATE registration SET password = '$password' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $ae);
    $af = "UPDATE registration SET weight = '$weight' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $af);
    $ag = "UPDATE registration SET status = '$status' where phone_number=" . $_SESSION['phone_number'];
    mysqli_query($db, $ag);
    header("location: profile.php");
}
if (isset($_POST['cancel'])) {
    header("location: profile.php");
}
if (isset($_POST['delete'])) {
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
    }
    $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
    if ($row = $strSQL->fetch_assoc()) {
        $_SESSION['id'] = $row['ID'];
    }
    $d = $db->query("DELETE FROM registration WHERE phone_number=".$_SESSION['phone_number']);
    $dd = $db->query("DELETE FROM profile WHERE ID='".$_SESSION['id']."'");
    header("location: registration.php");
}

//folder-------------------------->
$msg = "";
if (isset($_POST['upload'])) {
    $target = "healthdocs/" . basename($_FILES['file']['name']);
    if (move_uploaded_file($_FILES['file']['tmp_name'], $target)) {
        $msg = "File upload successful";
    } else {
        $msg = "Thare was problem uploading File";
    }

    $blood_report = $_FILES['file']['name'];
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);
    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
    }
    $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
    if ($row = $strSQL->fetch_assoc()) {
        $_SESSION['id'] = $row['ID'];
    }
    $q = $db->query("SELECT * FROM profile WHERE ID='" . $_SESSION['id'] . "'");
    while ($row = $q->fetch_assoc()) {
        if ($row['blood_report'] == "") {
            $c = $db->query("UPDATE profile SET blood_report='$blood_report' WHERE ID = '" . $_SESSION['id'] . "'");
        } else {
            $f = $db->query("UPDATE profile_folder SET folder='$blood_report' WHERE profile_ID = '" . $_SESSION['id'] . "'");
        }
    }
}

//settings----------------------->
if (isset($_REQUEST['add'])) {
    $sql = "SELECT * FROM registration WHERE phone_number='$phone_number'";
    $result = mysqli_query($db, $sql);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
    $count = mysqli_num_rows($result);

    if ($count == 1) {
        $_SESSION['phone_number'] = $phone_number;
    }
    $add_phone_number = mysqli_real_escape_string($db, $_REQUEST['add_phone_number']);
    $city = mysqli_real_escape_string($db, $_REQUEST['city']);
    $area = mysqli_real_escape_string($db, $_REQUEST['area']);

    $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
    if ($row = $strSQL->fetch_assoc()) {
        $_SESSION['id'] = $row['ID'];
    }
    if (!empty($add_phone_number) && !empty($city) && !empty($area)) {

        $aq = "UPDATE profile_settings SET add_phone_number='$add_phone_number',city='$city',area='$area' WHERE profile_ID='" . $_SESSION['id'] . "'";
        mysqli_query($db, $aq);
    }
    if (!(empty($add_phone_number)) && (empty($city) && empty($area))) {

        $ah = "UPDATE profile_settings SET add_phone_number = '$add_phone_number' WHERE profile_ID='" . $_SESSION['id'] . "'";
        mysqli_query($db, $ah);
    }
    if (!(empty($city) && empty($area)) && empty($add_phone_number)) {

        $ba = "UPDATE profile_settings SET city='$city',area='$area' WHERE profile_ID='" . $_SESSION['id'] . "'";
        mysqli_query($db, $ba);
    }
    header("location: profile.php");
}

//transactions-------------->
if (isset($_REQUEST['record'])) {
    $strSQL = $db->query("SELECT * FROM success WHERE phone_number='" . $_SESSION['phone_number']."'");
    if ($row = $strSQL->fetch_assoc()) {
        $_SESSION['id'] = $row['ID'];
    }
    $phone_number = mysqli_real_escape_string($db, $_REQUEST['phone_number']);
    $date = mysqli_real_escape_string($db, $_REQUEST['date_of_activity']);
    $iu = $db->query("SELECT * FROM success WHERE phone_number='$phone_number'");
    if ($row = $iu->fetch_assoc()) {
        $i = $row['ID'];
    }
    $donate = $_REQUEST['donation'];
    switch ($donate) {
        case 1:
            $ai = "INSERT INTO donation(r_ID,d_ID,date_of_activity,status) VALUES('" . $_SESSION['id'] . "','$i','$date','Donated')";
            mysqli_query($db, $ai);
            $ao = "INSERT INTO donation(r_ID,d_ID,date_of_activity,status) VALUES('$i','" . $_SESSION['id'] . "','$date','Received')";
            mysqli_query($db, $ao);
            break;
        case 2:
            $al = "INSERT INTO donation(r_ID,d_ID,date_of_activity,status) VALUES('" . $_SESSION['id'] . "','$i','$date','Received')";
            mysqli_query($db, $al);
            $am = "INSERT INTO donation(r_ID,d_ID,date_of_activity,status) VALUES('$i','" . $_SESSION['id'] . "','$date','Donated')";
            mysqli_query($db, $am);
            break;
    }
}
?>