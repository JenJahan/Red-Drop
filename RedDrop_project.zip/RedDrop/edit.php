<?php include('server.php'); ?>
<?php include('nav.php'); ?>
<!DOCTYPE html>
<?php
$strSQL = $db->query("SELECT * FROM registration where phone_number =" . $_SESSION['phone_number']);
if ($row = $strSQL->fetch_assoc()) {
    $p = $row['phone_number'];
    $n1 = $row['fname'];
    $n2 = $row['mname'];
    $n3 = $row['lname'];
    $d = $row['division'];
    $c = $row['city'];
    $a = $row['area'];
    $w = $row['weight'];
    $s = $row['status'];
    $pass = $row['password'];
}
?>
<html>
    <head>
        <style>
            body{padding-top:10px;}
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <div class = "header">
            <h2>Edit Profile</h2>
        </div>
        <div id =" content">
            <form method="post" action="edit.php?edit_form = <?php echo $p ?>" enctype="multipart/form-data">
                <div>
                    <input type="file" name="image">
                </div>
                </br>
                <?php
                $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $_SESSION['phone_number']);
                if ($row = $strSQL->fetch_assoc()) {
                    $_SESSION['id'] = $row['ID'];
                }
                $q = $db->query("SELECT * FROM profile WHERE ID='" . $_SESSION['id'] . "'");
                while ($row = $q->fetch_assoc()) {
                    if ($row['picture'] == "") {
                        echo "<img width = '150' height = '150'
                    src = 'image/default_avatar.png' alt = 'Default Profile Picture'>" . "</br>";
                    } else {
                        echo "<img width = '150' height = '150'
                    src = 'image/" . $row['picture'] . "' alt = 'Profile Picture'>" . "</br>";
                    }
                }
                ?>
                <div>
                    <input type="submit" name="submit">
                </div>
                </br></br>
                <div class = "input-group">
                    <label>Name:<br>First Name</label>
                    <input type = "text" name="fname" value="<?php echo $n1 ?>">
                    <label>Middle Name</label>
                    <input type = "text" name="mname" value="<?php echo $n2 ?>">
                    <label>Last Name</label>
                    <input type = "text" name="lname" value="<?php echo $n3 ?>">
                </div>
                <div class = "input-group">
                    <label>Division<select name ="division">
                            <option><?php echo $d ?></option>
                            <option value="Barishal">Barishal</option>
                            <option value="Chittagong">Chittagong</option>
                            <option value="Dhaka">Dhaka</option>
                            <option value="Khulna">Khulna</option>
                            <option value="Mymensingh">Mymensingh</option>
                            <option value="Rajshahi">Rajshahi</option>
                            <option value="Rongpur">Rongpur</option>
                            <option value="Syhlet">Syhlet</option>
                        </select>
                        <label>City<input type = "text" name="city" value="<?php echo $c ?>"></label>
                        <label>Area<input type = "text" name="area" value="<?php echo $a ?>"></label>
                </div>
                <div class = "input-group">
                    <label>Weight</label>
                    <select name = "weight">
                        <option><?php echo $w ?></option>
                        <?php
                        for ($i = 45; $i <= 200; $i++) {
                            ?>
                            <option value="<?php echo $i ?>"><?php echo $i ?></option>
                            <?php
                        }
                        ?>
                    </select>
                </div>
                <div> 
                    <label>Status</label>
                    <select name="status">
                        <option><?php echo $s ?></option>
                        <option value="Unmarried">Unmarried</option>
                        <option value="Married">Married</option>
                        <option value="Separated">Separated</option>
                        <option value="Widow">Widow</option>
                    </select>
                </div>
                <div class = "input-group">
                    <label>Password</label>
                    <input type = "password" name="password" value="<?php echo $pass ?>">
                </div>
                <div class = "input-group">
                    <button type = "submit" name="save_changes" class="btn">Save Changes</button>
                    <button type = "submit" name="cancel" class="btn">Cancel</button>
                    <span style="margin-left:8em"></span>
                    <button type = "submit" name="delete" class="btn">Delete</button>
                </div>
            </form> 
        </div>
    </body>
</html>