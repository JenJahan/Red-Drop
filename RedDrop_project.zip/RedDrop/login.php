<?php include('server.php') ?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            header {
                margin-top: 20px;
                padding-bottom: 10px;
            }
            .logo-row{
                text-align: center;
            }
            .logo {
                width: 300px;
                height: 100px;
                text-align: center;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
    </head>
    <body>
        <header>
            <div class="row">
                <div class="logo-row">
                    <img src="image\redDrop.png" alt="logo" class="logo">
                </div>
            </div>
        </header>
        <div class = "header">
            <h2>Log In</h2>
        </div>
        <form method="post" action="login.php">
            <?php include('errors.php'); ?>
            <div class = "input-group">
                <label>Phone Number</label>
                <input type = "text" name="phone_number">
            </div>
            <div class = "input-group">
                <label>Password</label>
                <input type = "password" name="password">
            </div>
            <div>
                <input type="checkbox" id="remember_me" name="_remember_me" checked />
                <label for="remember_me">Keep me logged in</label>
            </div>
            <div class = "input-group">
                <button type = "submit" name="login" class="btn">Log in</button>
            </div>
            <p>
                Not yet a member? <a href="registration.php">Sign up</a>
            </p>
        </form>
        <br /><br />
    </body>
</html>