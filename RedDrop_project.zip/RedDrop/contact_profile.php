<?php include('server.php'); ?>
<?php include('functions.php'); ?>
<?php include('nav.php'); ?>
<?php
if (!isset($_GET['ID'])) {
    header('location: contacts.php');
} else {
    $id = $_GET['ID'];
    $phone = getPhoneById($_GET['ID']);
}
$idd = getIdByPhone($phone);
?>
<!DOCTYPE html>
<html>
    <head>
        <style>
            * {
                margin: 0px;
                padding: 0px;
            }
            body{padding-top:10px;}
            body {
                font-size: 120%;
                background: #F8F8FF;
            }
            .header {
                width: 30%;
                margin: 50px auto 0px;
                color: white;
                background: #FF5C5C;
                text-align: center;
                border: 1px solid #333;
                border-bottom: 1px solid #333;
                border-radius: 10px 10px 0px 0px;
                padding: 20px;
            }
            .btn {
                padding: 10px;
                font-size: 15px;
                color: white;
                background:#d10000;
                border: none;
                border-radius: 5px;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
    </head>
    <body>
        <div class = "header">
            <h2>Contact Profile</h2>
        </div>
        <form method="post" action = "profile.php"> 
            <div class="col-xs-12 col-sm-12 col-md-6 col-lg-6 col-xs-offset-0 col-sm-offset-0 col-md-offset-3 col-lg-offset-3 toppad " align ="center" >
                <div class="panel panel-info">
                    <div class="panel-heading">
                        <h3 class="panel-title">
                            <?php
                            $strSQL = $db->query("SELECT fname,mname,lname FROM registration where phone_number =" . $phone);
                            if ($row = $strSQL->fetch_assoc()) {
                                echo $row['fname'] . "&nbsp";
                                if ($row['mname'] != NULL) {
                                    echo $row['mname'] . "&nbsp";
                                }
                                echo $row['lname'] . "<br />" . "<br />";
                            }
                            ?>
                            <div class="container">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="well well-sm">
                                            <div class="media">
                                                <div class="media-body">
                                                    <p>
                                                        <a href="chat.php?ID=<?php echo $idd; ?>" class="btn btn-xs btn-default"><span class="glyphicon glyphicon-comment"></span> Message</a>
                                                    </p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </h3>
                        <?php
                        $q = $db->query("SELECT * FROM profile_folder WHERE profile_ID='" . $id . "'");
                        $ff = $db->query("SELECT * FROM profile WHERE ID='" . $id . "'");
                        while ($row = $q->fetch_assoc()) {
                            if ($row['folder'] != "") {
                                while ($row = $ff->fetch_assoc()) {
                                    echo "</br></br><a href = 'healthdocs/" . $row['blood_report'] . "'>" . $row['blood_report'] . "</a";
                                }
                                echo "</br></br><a href = 'healthdocs/" . $row['folder'] . "'>" . $row['folder'] . "</a";
                            } else {
                                while ($row = $ff->fetch_assoc()) {
                                    if ($row['blood_report'] != "") {
                                        echo "</br></br><a href = 'healthdocs/" . $row['blood_report'] . "'>" . $row['blood_report'] . "</a";
                                    }
                                }
                            }
                        }
                        ?>
                    </div>
                    <div class="panel-body" >
                        <div class="row">
                            <br />
                            <?php
                            $strSQL = $db->query("SELECT * FROM success WHERE phone_number=" . $phone);
                            $q = $db->query("SELECT * FROM profile WHERE ID='" . $idd . "'");
                            while ($row = $q->fetch_assoc()) {
                                if ($row['picture'] == "") {
                                    echo "<img width = '150' height = '150'
                               src = 'image/default_avatar.png' alt = 'Default Profile Picture'>" . "</br>";
                                } else {
                                    echo "<img width = '150' height = '150'
                               src = 'image/" . $row['picture'] . "' alt = 'Profile Picture'>" . "</br>";
                                }
                            }
                            echo "<table style = 'width:50%' align = 'center'>
                        <tr>
                        <th>User Information</th>
                        </tr>";
                            $sql = $db->query("SELECT * FROM registration where phone_number =" . $phone);
                            $d = $db->query("SELECT COUNT(r_ID) FROM donation WHERE ((r_ID='" . $_SESSION['id'] . "') AND (status = 'Donated'))");
                            $r = $db->query("SELECT COUNT(d_ID) FROM donation WHERE (d_ID='" . $_SESSION['id'] . "' AND (status = 'Received'))");
                            $c = $db->query("SELECT * WHERE me='" . $_SESSION['id'] . "'");
                            if ($row = $sql->fetch_assoc()) {
                                echo "<tr><th></br>Country:&nbsp&nbsp<td></br>" . $row['country'] . "</td></th></tr>";
                                echo "<tr><th>Division:&nbsp&nbsp<td>" . $row['division'] . "</td></th></tr>";
                                echo "<tr><th>City:&nbsp&nbsp<td>" . $row['city'] . "</td></th></tr>";
                                echo "<tr><th>Area:&nbsp&nbsp<td>" . $row['area'] . "</td></th></tr>";
                                echo "<tr><th>Date of birth:&nbsp&nbsp<td>" . $row['date_of_birth'] . "</td></th></tr>";
                                $dateOfBirth = $row['date_of_birth'];
                                $today = date("Y-m-d");
                                $diff = date_diff(date_create($dateOfBirth), date_create($today));
                                echo "<tr><th>Age:&nbsp&nbsp<td>" . $diff->format('%y') . "</td></th></tr>";
                                echo "<tr><th>Blood group:&nbsp&nbsp<td>" . $row['blood_group'] . "</td></th></tr>";
                                echo "<tr><th>Gender:&nbsp&nbsp<td>" . $row['gender'] . "</td></th></tr>";
                                echo "<tr><th>Weight:&nbsp&nbsp<td>" . $row['weight'] . "</td></th></tr>";
                                echo "<tr><th>Status:&nbsp&nbsp<td>" . $row['status'] . "</td></th></tr>";
                                echo "<tr><th>Phone number:&nbsp&nbsp<td> +880" . $row['phone_number'] . "</td></th></tr>";
                                if ($row = $d->fetch_assoc()) {
                                    echo "<tr><th>Donation Count:&nbsp&nbsp<td>" . $row['COUNT(r_ID)'] . "</td></th></tr>";
                                }
                                if ($row = $r->fetch_assoc()) {
                                    echo "<tr><th>Receival Count:&nbsp&nbsp<td>" . $row['COUNT(d_ID)'] . "</td></th></tr>";
                                }
                            }
                            echo "</table></br></br>";
                            $s = $db->query("SELECT * FROM profile_settings WHERE profile_ID='" . $_SESSION['id'] . "'");
                            if ($row = $s->fetch_assoc()) {
                                if (($row['add_phone_number'] != 0) && ($row['city'] != "") && ($row['area'] != "")) {
                                    echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                                    echo "<strong>Contact number:</strong> +880" . $row['add_phone_number'] . "</br>";
                                    echo "<strong>Location:</strong> " . $row['city'] . " , " . $row['area'];
                                } else if ($row['add_phone_number'] != 0) {
                                    echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                                    echo "<strong>Contact number:</strong> +880" . $row['add_phone_number'] . "</br>";
                                } else if (($row['city'] != "") && ($row['area'] != "")) {
                                    echo "</br></br><strong>*ALSO AVAILABLE IN: </strong></br>";
                                    echo "<strong>Location:</strong> " . $row['city'] . " , " . $row['area'];
                                }
                            }
                            $db->close();
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </form> 
    </body>
</html>
