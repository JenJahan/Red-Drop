<?php include('server.php'); ?>
<?php include('functions.php'); ?>
<?php include('nav.php'); ?>
<html>
    <head>
        <style> 
            *{
                font-family:'Open Sans';
                box-sizing: border-box;
            }
            .chatContainer{
                width:400px;
                height:50px;
                border: 2px; 
            }
            .chatContainer>.chatHeader{
                width:100%;
                background: white;
                padding:5px;
                border-bottom: 1px solid
            }
            .input-group {
                margin: 10px 0px 10px 0px;
            }
            .input-group label {
                display: block;
                text-align: left;
                margin: 3px;
            }
            .input-group input {
                height: 30px;
                width: 93%;
                padding: 5px 10px;
                font-size: 16px;
                border-radius: 5px;
                border: 1px solid gray;
            }
            .btn {
                padding: 10px;
                font-size: 15px;
                color: white;
                background: #333;
                border: none;
                border-radius: 5px;
            }
        </style>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
        <link rel='stylesheet' type='text/css' href='css/style/css'/>
        <link href='http;//fonts.googleapis.com/css?family=Open+Sans:400,300,600,700,800'rel='stylesheet' type='text/css'>
        <script src="//code.jquery.com/jquery-1.11.0.min.js"></script>
    </head>
    <body>
        <div class='header'>
            <h2>Chat Records</h2>
        </div>
        <form action ="my_messages.php" method="post">
            <div class='chatContainer' style="margin-top: 50px;">
                <div class='ChatHeader'>
                    <h3>My chats</h3>
                </div>
                <div class='chatBottom'>
                    <?php
                    $query = "select * from chat_box where receiver_ID='" . getIdByPhone($_SESSION['phone_number']) . "' or sender_ID='" . getIdByPhone($_SESSION['phone_number']) . "';";
                    $result = mysqli_query($db, $query);
                    if ($row = mysqli_fetch_assoc($result)) {
                        $sql3 = "select * from registration where phone_number=" . getPhoneById($row['sender_ID']);
                        $result3 = mysqli_query($db, $sql3);
                        $row3 = mysqli_fetch_assoc($result3);
                        $reciever_name = $row3['fname'] . " " . $row3['lname'];
                        if (getIdByPhone($_SESSION['phone_number']) == $row['sender_ID']) {
                            echo "<a href=chat.php?ID=" . $row['receiver_ID'] . ">previousChats</a><br/>";
                        } else {
                            echo "<a href=chat.php?ID=" . $row['sender_ID'] . ">previousChats</a><br/>";
                        }
                    }
                    ?>
                </div>
            </div>
        </form>
    </body>
</html>
