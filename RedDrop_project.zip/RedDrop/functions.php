<?php
function getIdByPhone($phone)
{
    global $db;
    $query = "select * from success where phone_number='".mysqli_escape_string($db,$phone)."';";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    $p = $row['ID'];
    return $p;
}
function getPhoneById($id)
{
    global $db;
    $query = "select * from success where ID='".mysqli_escape_string($db, $id)."';";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['phone_number'];
}
function getChatId($id, $id1)
{
 global $db;
    $query = "select * from chat_box where (sender_ID='".
            mysqli_escape_string($db, $id)."' and receiver_ID='".
            mysqli_escape_string($db, $id1)."') or (sender_ID='".
            mysqli_escape_string($db, $id1)."' and receiver_ID='".
            mysqli_escape_string($db, $id)."');";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    return $row['chat_ID'];
}
function checkContact($id)
{
    global $db;
    $query = "select * from contacts where contact_ID='".mysqli_escape_string($db, $id)."';";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    if($row['contact_ID']){
        return true;
    }else{
        return false;
    }
}
function checkAccepted($id)
{
    global $db;
    $query = "select sender_ID from chat_box , contacts where sender_ID='".mysqli_escape_string($db, $id)."';";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    
    if($row['sender_ID']){
       return true;
    }else{
        return false;
    }
}
function profileContact($id)
{
    global $db;
    $query = "select contact_ID from profile, contacts where contact_ID='".mysqli_escape_string($db, $id)."';";
    $result = mysqli_query($db, $query);
    $row = mysqli_fetch_assoc($result);
    if($row['contact_ID']){
        return true;
    }else{
        return false;
    }
}