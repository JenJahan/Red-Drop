<?php include('server.php'); ?>
<?php
if(isset($_POST['add'])){
    $contact = $_POST['contact'];
    $me = $_POST['me'];
    $sq1 = "INSERT INTO contacts (contact_ID, me) VALUES('$contact', '$me')";
    mysqli_query($db, $sq1);
    echo("Error description: " . mysqli_error($db));
    //echo ""
    header("Location: contacts.php");
}
else
{
    header("Location: contacts.php");
}
?>


