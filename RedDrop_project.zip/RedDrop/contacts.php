<?php include('server.php'); ?>
<?php include('functions.php'); ?>
<?php include('nav.php'); ?>
<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Red Drop</title>
        <link rel ="stylesheet" type="text/css" href="style.css">
        <style>
            * {
                margin: 0px;
                padding: 0px;
            }
            body {
                font-size: 120%;
                background: #F8F8FF;
            }
            table,th{
                border-top: 2px solid #333;
                border-bottom: 1px solid #333;
                padding: 5px;
                margin-left: 30%;
            }
        </style>
    </head>
    <body>
        <div class = "header">
            <h2>My Contacts</h2>
        </div>
        </br></br>
        <div>
            <table style='width: 40%'>
                <th>Name</th>
                <?php
                $query = "select * from contacts where me='" . getIdByPhone($_SESSION['phone_number']) . "';";
                $result = mysqli_query($db, $query);
                while ($row = mysqli_fetch_array($result, MYSQLI_ASSOC)) {
                    echo "<tr>";
                    $sql3 = "select * from registration where phone_number=" . getPhoneById($row['contact_ID']);
                    $result3 = mysqli_query($db, $sql3);
                    $row3 = mysqli_fetch_array($result3, MYSQLI_ASSOC);
                    $name = $row3['fname'] . " " . $row3['mname']." " . $row3['lname'];
                    echo "<td><a href=contact_profile.php?ID=" . $row['contact_ID'] . ">" . $name . "</a></td>";
                    echo "</tr>";
                }
                ?>
            </table>
        </div>
    </body>
</html>